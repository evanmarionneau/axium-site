# Axium Développement — Site vitrine V1

Site statique responsive, conçu pour une mise en ligne simple avec GitHub Pages.

## Contenu

- `index.html` : page d'accueil
- `styles.css` : design responsive
- `script.js` : menu mobile et année automatique
- `favicon.svg` : icône provisoire
- `mentions-legales.html` : modèle à compléter
- `politique-confidentialite.html` : modèle à adapter

## Vérifications indispensables avant publication

1. Remplacer `contact@axium-developpement.fr` par une adresse réellement créée.
2. Compléter les mentions légales après l'immatriculation.
3. Vérifier l'orthographe et le périmètre exact des prestations.
4. Ajouter le nom du directeur de la publication.
5. Vérifier les coordonnées de l'hébergeur.
6. Ne pas ajouter Google Analytics, Meta Pixel, vidéos intégrées ou formulaire tiers
   sans adapter la politique de confidentialité et, si nécessaire, le consentement cookies.

## Prévisualisation locale

Ouvrir simplement `index.html` dans un navigateur.

Pour un serveur local :

```bash
python3 -m http.server 8000
```

Puis ouvrir `http://localhost:8000`.

## Publication GitHub Pages

1. Créer un dépôt GitHub, par exemple `axium-site`.
2. Ajouter tous les fichiers à la racine du dépôt.
3. Dans GitHub : `Settings` → `Pages`.
4. Choisir le déploiement depuis une branche.
5. Sélectionner la branche principale et le dossier `/root`.
6. Enregistrer.

Le site sera disponible sur une adresse de type :
`https://VOTRE-IDENTIFIANT.github.io/axium-site/`

## Domaine personnalisé

Le domaine n'est pas inclus dans ce dossier. Ne l'achetez qu'après avoir :
- validé définitivement le nom Axium Développement ;
- vérifié la disponibilité juridique et du nom de domaine ;
- confirmé le calendrier réel d'immatriculation.

## Positionnement de cette V1

Cette version est volontairement légère : elle sert à présenter le projet,
tester le discours commercial et préparer une future présence en ligne,
sans engager un abonnement ou un développement coûteux.
